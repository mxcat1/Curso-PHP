
CREATE PROCEDURE [dbo].[DeletePersistedStream]
@SessionID varchar(32),
@Index int
AS

delete from [ReportServer$MXCATMSBDTempDB].dbo.PersistedStream where SessionID = @SessionID and [Index] = @Index
go

