


CREATE PROCEDURE [dbo].[registrarUsuario](
@correoUsuario VARCHAR(100),
@claveUsuario VARCHAR(20),
@nombresUsuario VARCHAR(50),
@apePatUsuario VARCHAR(50),
@apeMatUsuario VARCHAR(50),
@dniUsuario VARCHAR(8),
@fecNacimientoUsuario DATE,
@telefonoUsuario VARCHAR(9),
@celularUsuario VARCHAR(11),
@idRol INT
)
AS
BEGIN
	INSERT INTO tb_usuario(correoUsuario,claveUsuario,nombresUsuario,apePatUsuario,
						apeMatUsuario,dniUsuario,fecNacimientoUsuario,telefonoUsuario,
						celularUsuario,idRol)
	VALUES (@correoUsuario,@claveUsuario,@nombresUsuario,@apePatUsuario,
						@apeMatUsuario,@dniUsuario,@fecNacimientoUsuario,@telefonoUsuario,
						@celularUsuario,@idRol)

END


go

