
create function REPORTPAGO (@cliente varchar(300))
RETURNS TABLE return 
select p.in_id_pago,p.cliente,p.tipo,p.documento,pr.nomProducto,cantidad,CONVERT(VARCHAR(19),precio) as "precio" ,CONVERT(VARCHAR(19),p.fecha,103) as "Fecha" from pagoconsulta as p inner join DETALLEPAGO as dt on dt.in_id_pago=p.in_id_pago inner join tb_producto pr on dt.idProducto=pr.idProducto  where p.cliente like '%'+@cliente+'%'  and p.in_id_pago = (select max(in_id_pago) from pago)
go

