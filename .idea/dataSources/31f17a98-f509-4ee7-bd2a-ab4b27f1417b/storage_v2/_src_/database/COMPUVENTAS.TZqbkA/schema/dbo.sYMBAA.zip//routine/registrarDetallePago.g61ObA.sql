create PROCEDURE [dbo].[registrarDetallePago](
@idVenta INT,
@idProducto INT,
@cantidad INT,
@precio DECIMAL(6,2)
)
AS
BEGIN
INSERT INTO DETALLEPAGO(in_id_pago,idProducto,cantidad,precio,subtotal,estadoVentaxProd)
	VALUES(@idVenta,@idProducto,@cantidad,@precio,@cantidad*@precio,1)

UPDATE tb_producto
SET stockProducto = stockProducto-@cantidad
WHERE idProducto = @idProducto
update pago
set total = (select Round((sum(precio * cantidad)),2) from detallepago)
 where in_id_pago = (select max(in_id_pago) from pago)
END

go

