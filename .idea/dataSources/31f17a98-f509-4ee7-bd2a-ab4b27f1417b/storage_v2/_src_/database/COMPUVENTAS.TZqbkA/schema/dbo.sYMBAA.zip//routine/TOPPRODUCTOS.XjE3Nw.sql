


create FUNCTION [dbo].[TOPPRODUCTOS] (@prod INT,@fecha datetime,@fecha2 datetime) 
RETURNS TABLE return 
select TOP (@prod) dp.idProducto, pr.nomProducto , CONVERT(VARCHAR(60),sum (precio*cantidad)) as "Total" from DETALLEPAGO dp  inner join tb_producto pr on dp.idProducto =pr.idProducto inner join pago pa on dp.in_id_pago=pa.in_id_pago where pa.dt_fechaEmision between @fecha and  @fecha2 group by dp.idProducto, pr.nomProducto  order by total desc

go

