
create FUNCTION [dbo].[PEDIDOXPRODUCTOXTODOS] (@prod varchar(300),@fecha datetime,@fecha2 datetime) 
RETURNS TABLE return 
select dp.in_id_pago, u.nombresUsuario + ' '+ u.apePatUsuario + ' ' + u.apeMatUsuario as 'Cliente',d.descri,p.dt_fechaEmision,p.total from detallepago dp inner join tb_producto pr on dp.idProducto = pr.idProducto inner join pago p on p.in_id_pago = dp.in_id_pago inner join DocPaga d on d.documentopaga=p.documentopaga inner join tb_usuario u on u.idUsuario=p.idCliente where pr.nomProducto like '%'+@prod+'%' and p.dt_fechaEmision between @fecha and @fecha2  group by dp.in_id_pago,d.descri,p.total, u.nombresUsuario,  u.apePatUsuario , u.apeMatUsuario,p.dt_fechaEmision

go

