
create PROCEDURE [dbo].[registrarPago](
@idUsuario INT,
@tipo bit,
@tipo2 bit,
@tarjeta varchar (100),
@fechaven date,
@cvc char(4),
@doc int
)
AS
BEGIN
INSERT INTO PAGO(idUsuario,idCliente, in_id_tipopaVisa,in_id_tipopaMastercard ,vc_dsc_numerotar , fechaven ,cvc , dt_fechaEmision,in_id_estado,documentopaga)
	VALUES(null,@idUsuario,@tipo,@tipo2,@tarjeta,@fechaven,@cvc, GETDATE(),1,@doc)
	
	
END

go

