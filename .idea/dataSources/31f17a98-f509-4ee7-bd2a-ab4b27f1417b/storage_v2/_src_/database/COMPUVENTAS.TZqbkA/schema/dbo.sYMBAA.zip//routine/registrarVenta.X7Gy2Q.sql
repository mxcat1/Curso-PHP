
CREATE PROCEDURE [dbo].[registrarVenta](
@idUsuario INT,
@estadoVenta BIT
)
AS
BEGIN
INSERT INTO tb_venta(idUsuario,fechaVenta,estadoVenta)
	VALUES(@idUsuario,GETDATE(),1)
END

go

