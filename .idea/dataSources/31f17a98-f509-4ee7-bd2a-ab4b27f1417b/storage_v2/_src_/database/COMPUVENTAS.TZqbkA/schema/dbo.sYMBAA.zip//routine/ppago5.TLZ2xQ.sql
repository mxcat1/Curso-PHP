

create proc [dbo].[ppago5]
as
declare 
@tipo varchar(100)
if exists(select * from PAGO where in_id_tipopaVisa  = 1 )
begin

set @tipo='VISA'
 insert into pagoconsulta(in_id_pago,cliente,tipo,documento,fecha,total)
select p.in_id_pago  , u.nombresUsuario + ' '+ u.apePatUsuario + ' ' + u.apeMatUsuario as 'Cliente', @tipo,d.descri ,p.dt_fechaEmision ,total from pago p inner join  detallepago dt on p.in_id_pago = dt.in_id_pago inner join tb_producto pr on pr.idProducto = dt.idProducto inner join DocPaga d on d.documentopaga=p.documentopaga inner join tb_usuario u on u.idUsuario=p.idCliente where pr.descProducto like '%%' and in_id_tipopaVisa  = 1   and p.in_id_pago = (select max(in_id_pago) from PAGO)group by p.in_id_pago,p.dt_fechaEmision,u.nombresUsuario, u.apePatUsuario , u.apeMatUsuario,d.descri,total 


end
if exists(select * from PAGO where in_id_tipopaMastercard  = 1 )
begin
set @tipo='MASTER CARD'
 insert into pagoconsulta(in_id_pago,cliente,tipo,documento,fecha,total)
  select p.in_id_pago  , u.nombresUsuario + ' '+ u.apePatUsuario + ' ' + u.apeMatUsuario as 'Cliente', @tipo ,d.descri ,p.dt_fechaEmision ,total from pago p inner join  detallepago dt on p.in_id_pago = dt.in_id_pago inner join tb_producto pr on pr.idProducto = dt.idProducto inner join DocPaga d on d.documentopaga=p.documentopaga inner join tb_usuario u on u.idUsuario=p.idCliente where pr.descProducto like '%%' and  in_id_tipopaMastercard  = 1   and p.in_id_pago = (select max(in_id_pago) from PAGO) group by p.in_id_pago,p.dt_fechaEmision,u.nombresUsuario, u.apePatUsuario , u.apeMatUsuario,d.descri,total

end

go

