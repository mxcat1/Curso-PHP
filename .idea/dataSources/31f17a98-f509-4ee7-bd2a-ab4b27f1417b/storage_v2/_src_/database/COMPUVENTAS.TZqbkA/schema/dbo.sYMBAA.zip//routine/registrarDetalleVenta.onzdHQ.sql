
CREATE PROCEDURE [dbo].[registrarDetalleVenta](
@idVenta INT,
@idProducto INT,
@cantidad INT,
@precio DECIMAL(6,2)
)
AS
BEGIN
INSERT INTO tb_ventaxproducto(idVenta,idProducto,cantidad,precio,subtotal,estadoVentaxProd)
	VALUES(@idVenta,@idProducto,@cantidad,@precio,@cantidad*@precio,1)

UPDATE tb_producto
SET stockProducto = stockProducto-@cantidad
WHERE idProducto = @idProducto
END

go

