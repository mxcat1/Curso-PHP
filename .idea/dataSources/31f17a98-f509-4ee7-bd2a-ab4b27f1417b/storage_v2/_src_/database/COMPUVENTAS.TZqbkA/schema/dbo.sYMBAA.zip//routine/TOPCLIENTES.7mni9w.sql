create function [dbo].[TOPCLIENTES](@prod int,@fecha datetime,@fecha2 datetime)
RETURNS TABLE return 
select TOP (@prod) in_id_pago,cliente,tipo,documento,CONVERT(VARCHAR(19),fecha,103) as "Fecha",CONVERT(VARCHAR(50),total) as "Total" from pagoconsulta where fecha between @fecha and @fecha2  group by in_id_pago,cliente,tipo,documento,fecha,total order by total desc

go

