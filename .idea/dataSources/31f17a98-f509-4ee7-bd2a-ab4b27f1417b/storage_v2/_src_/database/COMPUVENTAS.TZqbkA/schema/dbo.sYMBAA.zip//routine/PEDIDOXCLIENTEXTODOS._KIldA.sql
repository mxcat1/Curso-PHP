
create FUNCTION [dbo].[PEDIDOXCLIENTEXTODOS] (@prod varchar(300),@fecha datetime,@fecha2 datetime) 
RETURNS TABLE return 
select in_id_pago,cliente,tipo,documento,CONVERT(VARCHAR(19),fecha,103) as "Fecha",CONVERT(VARCHAR(19),total) as "Total" from pagoconsulta where cliente like '%'+@prod+'%' and fecha between @fecha and @fecha2  group by in_id_pago,cliente,tipo,documento,fecha,total

go

